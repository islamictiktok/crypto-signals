import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from golden_consensus_bot import (  # noqa: E402
    AnalystResult,
    ConsensusEngine,
    add_indicators,
)


class EngineTests(unittest.TestCase):
    def make_candles(self, n=240):
        rows = []
        price = 100.0
        for i in range(n):
            price += 0.20 if i % 7 != 0 else -0.05
            rows.append({
                "t": i * 1_800_000,
                "o": price - 0.10,
                "h": price + 0.35,
                "l": price - 0.35,
                "c": price,
                "v": 1_000 + (100 if i % 20 == 0 else 0),
            })
        return pd.DataFrame(rows)

    def test_indicators_are_created_on_closed_candles(self):
        result = add_indicators(self.make_candles())
        for column in ["ema20", "ema50", "ema200", "rsi14", "atr14", "macd_hist", "adx14", "volume_ratio"]:
            self.assertIn(column, result.columns)
        self.assertGreater(result["ema200"].iloc[-1], 0)
        self.assertGreater(result["atr14"].iloc[-1], 0)

    def test_consensus_accepts_three_aligned_analysts(self):
        results = [
            AnalystResult("trend", "LONG", 90, 0.30),
            AnalystResult("structure", "LONG", 80, 0.25),
            AnalystResult("momentum", "LONG", 75, 0.25),
            AnalystResult("liquidity", "NEUTRAL", 35, 0.20),
        ]
        consensus = ConsensusEngine.decide(results, 65)
        self.assertIsNotNone(consensus)
        self.assertEqual(consensus.direction, "LONG")
        self.assertGreaterEqual(consensus.confidence, 65)

    def test_consensus_rejects_two_vs_two(self):
        results = [
            AnalystResult("a", "LONG", 90, 0.25),
            AnalystResult("b", "LONG", 90, 0.25),
            AnalystResult("c", "SHORT", 90, 0.25),
            AnalystResult("d", "SHORT", 90, 0.25),
        ]
        self.assertIsNone(ConsensusEngine.decide(results, 65))

    def test_consensus_rejects_strong_opposition(self):
        results = [
            AnalystResult("a", "LONG", 95, 0.30),
            AnalystResult("b", "LONG", 85, 0.25),
            AnalystResult("c", "LONG", 80, 0.25),
            AnalystResult("d", "SHORT", 90, 0.20),
        ]
        self.assertIsNone(ConsensusEngine.decide(results, 65))


if __name__ == "__main__":
    unittest.main()
